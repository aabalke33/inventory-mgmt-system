module balke.c482 {
    requires javafx.controls;
    requires javafx.fxml;


    opens balke.c482 to javafx.fxml;
    exports balke.c482;
}